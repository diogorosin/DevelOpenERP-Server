INSERT INTO "Catalog"("position", "active", "denomination", "company")
VALUES (0, true, 'Ingressos', 4);

INSERT INTO "Catalog"("position", "active", "denomination", "company")
VALUES (1, truE, 'Entretenimento', 4);

INSERT INTO "Catalog"("position", "active", "denomination", "company")
VALUES (2, true, 'Instalações', 4);

INSERT INTO "Catalog"("position", "active", "denomination", "company")
VALUES (3, true, 'Bebidas', 4);

INSERT INTO "Catalog"("position", "active", "denomination", "company")
VALUES (4, true, 'Comidas', 4);

INSERT INTO "Catalog"("position", "active", "denomination", "company")
VALUES (5, true, 'Sorvetes', 4);



