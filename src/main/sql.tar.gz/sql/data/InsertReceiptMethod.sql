INSERT INTO "ReceiptMethod"("identifier", "denomination")
VALUES ('DIN', 'Dinheiro');

INSERT INTO "ReceiptMethod"("identifier", "denomination")
VALUES ('CCR', 'Cartão de Crédito');

INSERT INTO "ReceiptMethod"("identifier", "denomination")
VALUES ('CDE', 'Cartão de Débito');

INSERT INTO "ReceiptMethod"("identifier", "denomination")
VALUES ('CHE', 'Cheque');
