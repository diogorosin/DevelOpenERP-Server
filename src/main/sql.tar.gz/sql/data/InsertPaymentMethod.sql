INSERT INTO "PaymentMethod"("identifier", "denomination")
VALUES ('DIN', 'Dinheiro');
