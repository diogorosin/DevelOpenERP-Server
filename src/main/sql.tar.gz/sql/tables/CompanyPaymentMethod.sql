CREATE TABLE "CompanyPaymentMethod" (

	"company" INTEGER NOT NULL,

	"paymentMethod" VARCHAR(3) NOT NULL

);
