CREATE TABLE "CompanyReceiptMethod" (

	"company" INTEGER NOT NULL,

	"receiptMethod" VARCHAR(3) NOT NULL

);
