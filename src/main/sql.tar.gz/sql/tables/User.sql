CREATE TABLE "User" (

    "individual" INTEGER NOT NULL,

    "login" VARCHAR(254) NOT NULL,

    "password" VARCHAR(64) NOT NULL,
    
    "numericPassword" VARCHAR(4) NOT NULL,

    "lastLoggedInCompany" INTEGER

);