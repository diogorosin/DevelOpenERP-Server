CREATE TABLE "PaymentMethod" (

	"identifier" VARCHAR(3) NOT NULL,

	"denomination" VARCHAR(20) NOT NULL

);
