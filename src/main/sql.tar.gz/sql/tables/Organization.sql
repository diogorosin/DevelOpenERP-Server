CREATE TABLE "Organization" (

    "subject" INTEGER NOT NULL,

    "denomination" VARCHAR(100) NOT NULL,

    "fancyName" VARCHAR(32)

);
