CREATE TABLE "Subject" (

    "identifier" INTEGER DEFAULT NEXTVAL('SubjectSequence') NOT NULL,

    "active" BOOLEAN NOT NULL,

    "address" INTEGER

);
