CREATE TABLE "CompanyDeviceSale" (

	"company" INTEGER NOT NULL,

	"device" INTEGER NOT NULL,

	"sale" INTEGER NOT NULL,

	"number" INTEGER NOT NULL,

	"status" VARCHAR(1) NOT NULL,

	"dateTime" TIMESTAMP NOT NULL,

	"user" INTEGER NOT NULL,

	"note" VARCHAR(200)

);
