CREATE TABLE "ReceiptMethod" (

	"identifier" VARCHAR(3) NOT NULL,

	"denomination" VARCHAR(20) NOT NULL

);
