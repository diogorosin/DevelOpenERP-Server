CREATE TABLE "Individual" (
	
	"subject" INTEGER NOT NULL,

	"name" VARCHAR(100) NOT NULL

);
