CREATE TABLE "Token" (

    "identifier" VARCHAR(10) NOT NULL,

    "company" INTEGER NOT NULL,

    "user" INTEGER NOT NULL,

    "expire" TIMESTAMP

);
