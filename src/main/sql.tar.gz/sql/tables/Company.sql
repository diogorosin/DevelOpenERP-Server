CREATE TABLE "Company" (

	"organization" INTEGER NOT NULL,

	"couponTitle" VARCHAR(32) NOT NULL,

	"couponSubtitle" VARCHAR(32)

);
