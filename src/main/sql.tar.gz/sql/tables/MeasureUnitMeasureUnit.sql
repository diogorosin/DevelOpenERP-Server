CREATE TABLE "MeasureUnitMeasureUnit" (

	"from" INTEGER NOT NULL,

	"to" INTEGER NOT NULL,

	"factor" NUMERIC(14,4) NOT NULL

);
