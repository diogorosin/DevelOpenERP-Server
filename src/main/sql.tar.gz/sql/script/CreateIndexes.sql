CREATE UNIQUE INDEX "UserLoginIdx" ON "User"("login");
CREATE UNIQUE INDEX "DeviceSerialNumberIdx" ON "Device"("serialNumber");
CREATE UNIQUE INDEX "OrganizationDenominationIdx" ON "Organization"("denomination");
